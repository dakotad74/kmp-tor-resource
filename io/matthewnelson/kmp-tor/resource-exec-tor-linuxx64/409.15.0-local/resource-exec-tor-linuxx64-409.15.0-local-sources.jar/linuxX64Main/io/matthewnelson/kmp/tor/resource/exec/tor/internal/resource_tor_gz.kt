/*
 * Copyright (c) 2023 Matthew Nelson
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/
@file:Suppress("ClassName", "ConstPropertyName")

package io.matthewnelson.kmp.tor.resource.exec.tor.internal

// This is an automatically generated file.
// DO NOT MODIFY

import io.matthewnelson.kmp.tor.common.api.InternalKmpTorApi
import io.matthewnelson.kmp.tor.common.core.NativeResource

@OptIn(InternalKmpTorApi::class)
internal object resource_tor_gz: NativeResource(
    version = 1,
    name = "tor.gz",
    size = 1765L,
    sha256 = "cdd2c6cccf58e63463747048ad7cf7c04c8233d63209ff7d2e2140c364d78759",
    chunks = 1L,
) {

    @Throws(IllegalStateException::class, IndexOutOfBoundsException::class)
    override operator fun get(index: Long): Chunk = when (index) {
        0L -> _0
        else -> throw IndexOutOfBoundsException()
    }.toChunk()

    private const val _0 =
"""H4sIAAAAAAACA+1bbWwURRievWt7Vz56p4BWWugFCwH1ttcPmqI5QErpnSlQ2kJC
BI5tb9tech/1bk9a4seR+lWBpBiiJCamJiZi+GETNOGHJMUa1JgYamJSf1mJJCWK
1igNiuk6c/vOdXa84xA08cc8ZPfZ9533mZmdmZ3usTPPN7Vss0gSorCijYhYKadh
bwa/rzoTgn0NaDE+r0DlqAjbBUwcz5MWM9sz5Ri6Uqth81yOzCwxXIByI1VkZuSc
1xUyNs9vS2ZmdenyXODneAqZmdWRKgy7DXvYa+YUtMcrFrPOAroR0I14zey0mJm2
ZwEcDdB+PHuQmXldL8TxvBWZmbZ9+xUteCfltYKuANqP5zpkZlreLqwrQrcP2r1t
UF6ufuizmJl2f1U41FlfVxUOusOhaLLf3d9Q766vkxMxuSZTLxeMqeYdu0m/jRXA
uE73Y8qwJeY+lkI6iX+p57pNmfVvjJ35ofBTpPqT79YNF0C9JYihz4mFuS9ybWPG
F0JH0mcbpE+oX0Zu1S7b8HFvFn8gh19ihjyLFTn8j+Tw78mR/1P4WJWtogF/x/ZA
UI2rPaGEpsY7tjeGY1G1Q+kMqygQ6InEooGEpsS1QMAIzRq4s7VpR3t7S6ArrCrR
ZB/SYvFARAlFcQ64f7sgB/B09SuB7lBUCYcOqwgn42Dc3+Sqi/R7PWpu8W9pDNTI
NfL6zHVtHarc2eZv9u8wWsuCD+OfFVHPq8x4TC4PFZNePQm+D068XkR6dQSZxyV9
Xg7eY/Apzu8Cv32z2U/tyU0GF3HjZ4rxWxn/NONn59cZxl/I+G8wfhvj/wz8Nmbs
E1xi/P/kORYQEBAQEBAQEPh38atj5R++wR/tvqOF31Thn/kvjmkW/ZJv8BP7eDpd
X/8aduurT+Kzo2JzOr6XJFy9rOt693DaJi96V7/K2Prqt3B0t6Niq5G/vvoAZ+8x
2dXX/EMTB3xDl32D38+0djRVj1V/7jvunSDFL6vFob91y46KF4z/hzju3Uvqebyw
jdCGG9oyXPX7oOrF+pSjIkXixoFx/Lp0/PpVhNbN+YZmfBd+2uS7cMPqky76Jua0
pTiDK7KRgV2fMupF9aR+KS9JRsmHd/sGvR+TS9/QFW2R76j3Ijami/GNTwfx6WLh
eWxL+7HWpL96CCcydvv07JyuD41Pf4vpHGm8IzfJy7KjcXJo8snx+T7J9IKAgICA
gICAgICAgICAwN0h/cWqzPoY+U5Lvu+Uz+h6EHML5mOY92F+B/MzmFswh3/R9Y+Q
8S0zrT/chqR+p1S2yGYflgw/+Wa/FsevIQFbbelPX5XI+KY7+rOup78Jlzi3lZQ+
4Vh4yJ5Cm5ZveKi2Mv0ZkOj34eMcjnMy9SR+DfQuxl+KD1LP07i8B4mjqcQ5aNlf
YhddKyAgICAgICAgICDwPwdd70fX99E1dClktl8FXgF8BngRzQh+PC0G8yTk9wDY
dJ1hGdj099JyYLresJxLvz6nxwiPwuJBuibwFCwapGv7JiF9AdhngRcyv9sIlnH3
T9ckjsJ6Qbp20cP8DiSgaw7vB24tMvuHC831HgMu5spfyd3fTd24Pwlcc2AfhPz0
+fQ0ZsBugfTfwbb+R+ODrgPn4aHr9Z13li9dN9rc2Pioa+3uzmRUS7qqa+Va2eOu
T6bNmudq6mRPnVy9DhIQkhO9CS2uKZ1IDkU1Nd6H5GhMU+WeaFLui8f61Lg2wLg6
k6Fw0B0KguvxLX63pvSgdFqvkuhFcnAgmhiIGKzFjZSn1XgiFIuajABOi6thhQTC
VV9YI7UI4TO+lHticJFQu5Csqf3Y7MbJODoWVDQFyWpvoDuuRNRAbzA+bxl5BJR4
XBkwFPQaF6VEQjgzQ96ZSCC5KxaJqFHt7vt1IYwpOt5z7YdA3DxAsQTGPtXnWo+P
uPFOsYbT8/sAKrl4fg/GBk5/zGpmVx59Mz5m8bND9XR+GeXKL8pR/13QhhZu/qE8
xswbEqOn88BeZF5rT+czymfztL8CcwPV0/mAspOrv4XjKMw11KbzDWVPjvpTPAtt
auHmP8pjOdqP3v/LoN/CzaeUPYy+NIv+BGL3JKC/7a8py9P/xzi9y2lmfvzy23je
4PStTjM78+hHOP1Bp5ldefTvcXq6f4ryEim7nuJ9Tk//XlNenKf9PgR9Zo+Fy8wF
OfSUz3PzT659ObnK/4LTN7jMfDrP/PM1PkqYv5uZfTru7PF2jr/Dh4PR0/eXU7ep
v4bMeyIy+65AT/db2Tgd7cc34f7595fRKhiHecqf5fSZDXSe7OOFv58/wUf1TtA7
Pdnj+fmLbAGUsj1n4HDn0LOc7Z3HC/oF0q3L/wu+feBRiDgAAA=="""

}
